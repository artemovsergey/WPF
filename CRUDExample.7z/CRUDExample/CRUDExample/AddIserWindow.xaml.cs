﻿using CRUDExample.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CRUDExample
{

    public partial class AddIserWindow : Window
    {
        User currentUser;

        public AddIserWindow(User user)
        {
            InitializeComponent();

            if(user == null)
            {
                currentUser = null;
            }
            else
            {
                currentUser = user;
                DataContext = currentUser;
            }
        }

        
        /// <summary>
        /// Сохранение или добавление нового пользователя
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SaveUserclick(object sender, RoutedEventArgs e)
        {
            using(UserContext db = new UserContext())
            {

                if(currentUser == null)
                {
                    User user = new User() { Name = NameBox.Text, Age = Convert.ToInt32(AgeBox.Text) };
                    // валидация?
                    db.Users.Add(user);
                }
                else
                {
                    db.Users.Update(currentUser);
                }


               
               

                try
                {
                    db.SaveChanges();
                    MessageBox.Show("Пользователь добавлен!");

                    //Proxy.userGrid.ItemsSource = db.Users.ToList(); // производительность?

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

            }
        }
    }
}
