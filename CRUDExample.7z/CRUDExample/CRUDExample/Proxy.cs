﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace CRUDExample
{
    public class Proxy
    {

       public static DataGrid userGrid { get; set; }

    } 
}
