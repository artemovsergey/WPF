﻿using CRUDExample.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CRUDExample
{

    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            using(UserContext db = new UserContext())
            {
                usersGrid.ItemsSource = db.Users.ToList();


                

                

                Proxy.userGrid = usersGrid;
            }
        }

        
        /// <summary>
        /// Переход на окно добаления или редактирования
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AddUserClick(object sender, RoutedEventArgs e)
        {
            new AddIserWindow(null).ShowDialog();
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void usersGrid_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            User user = (User)usersGrid.SelectedItem;
            new AddIserWindow(user).ShowDialog();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_KeyDown(object sender, KeyEventArgs e)
        {

            if (e.Key == Key.F5)
            {

                using (UserContext db = new UserContext())
                {
                    usersGrid.ItemsSource = db.Users.ToList();
                    Proxy.userGrid = usersGrid;
                }

            }

        }

        
        /// <summary>
        /// Удаление пользователя
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DeleteUserClick(object sender, RoutedEventArgs e)
        {
            var selectedUsers = usersGrid.SelectedItems.Cast<User>().ToList();

            if (MessageBox.Show($"Вы точно хотите удалить {selectedUsers.Count()} пользователей", "Внимание!",
                 MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    UserContext db = new UserContext();
                    db.Users.RemoveRange(selectedUsers);
                    db.SaveChanges();
                    usersGrid.ItemsSource = db.Users.ToList();
                    MessageBox.Show("Пользователи удалены!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"{ex.Message}");
                }
            }
        }
    }
}
