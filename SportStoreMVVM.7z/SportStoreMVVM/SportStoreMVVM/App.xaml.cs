﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using SportStoreMVVM.Views;

namespace SportStoreMVVM
{

    public partial class App : Application
    { 
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);
            Views.MainWindow mv = new Views.MainWindow();

            //MainWindowViewModel vm = new MainWindowViewModel();
            //mv.DataContext = vm;

            mv.Show();
        }
    }
}
